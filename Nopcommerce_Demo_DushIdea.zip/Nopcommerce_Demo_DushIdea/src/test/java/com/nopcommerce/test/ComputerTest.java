package com.nopcommerce.test;

import java.util.HashMap;
import org.testng.annotations.Test;
import com.nopcommerce.base.ProjectSpecifiedMethod;
import com.nopcommerce.pages.ComputerPage;
import com.nopcommerce.pages.DesktopsPage;
import com.nopcommerce.pages.HomePage;
import com.nopcommerce.pages.LoginPage;
import com.nopcommerce.pages.ShoppingCartPage;
import com.nopcommerce.utils.ReadExcelData;

public class ComputerTest extends ProjectSpecifiedMethod {

	HomePage homepage;
	LoginPage loginPage;
	ComputerPage computerPage;
	DesktopsPage desktopspage;
	ShoppingCartPage shoppingCartPage;
	String testcasename;
	public HashMap<String, String> readdata;

	@Test
	public void TC_001_FullFlowComputerTest() throws Exception {
		testcasename = new Exception().getStackTrace()[0].getMethodName();
		readdata = ReadExcelData.readDataTest(testcasename);
		
		homepage = new HomePage(driver);
		homepage.clickOnLogIn();
		loginPage = new LoginPage(driver, readdata);
		loginPage.setUpLogin();
		homepage.clickOnComputers();
		computerPage = new ComputerPage(driver);
		computerPage.clickOnDesktops();
		desktopspage = new DesktopsPage(driver,readdata);
		desktopspage.fullFlowComputerTest();
		homepage.clickOnShoppingCart();
		shoppingCartPage = new ShoppingCartPage(driver,readdata);
		shoppingCartPage.giftWrappingCheckout();
	}
}
