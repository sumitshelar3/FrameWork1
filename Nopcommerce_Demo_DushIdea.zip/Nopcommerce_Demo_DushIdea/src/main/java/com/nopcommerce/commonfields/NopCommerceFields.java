package com.nopcommerce.commonfields;

public interface NopCommerceFields {
	String loginClick = "//a[contains(text(),'Log in')]";
	String computerClick = "//a[contains(text(),'Computers')]";
	String elementsClick = "//a[contains(text(),'Electronics')]";
	String apparelClick = "//a[contains(text(),'Apparel')]";
	String shoppingCartClick = "//span[contains(text(),'Shopping cart')]";
}
