package com.nopcommerce.core;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SeleniumCoreMethods {
	public WebDriver driver;
	public static Actions actions;
	public Select dropdown;

	public SeleniumCoreMethods(WebDriver drivercon) {
		driver = drivercon;
	}

	public void clickElementBy(String webelement, String locator) {
		try {
			if (driver != null) {
				if (locator.equalsIgnoreCase("xpath")) {
					driver.findElement(By.xpath(webelement)).click();
				} else if (locator.equalsIgnoreCase("id")) {
					driver.findElement(By.id(webelement)).click();
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sendKeysElement(String webelement, String locator, String elementValue) {
		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				driver.findElement(By.xpath(webelement)).sendKeys(elementValue);
			} else if (locator.equalsIgnoreCase("id")) {
				driver.findElement(By.id(webelement)).sendKeys(elementValue);
			}
		}
	}

	public void dropDownElement(String webelement, String locator, String elementvalue, String selectdropdownby) {

		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				dropdown = new Select(driver.findElement(By.xpath(webelement)));
				dropSelectValueBy(dropdown, elementvalue, selectdropdownby);
			} else if (locator.equalsIgnoreCase("id")) {
				dropdown = new Select(driver.findElement(By.id(webelement)));
				dropSelectValueBy(dropdown, elementvalue, selectdropdownby);
			}
		}
	}

	public void dropSelectValueBy(Select select, String elementvalue, String selectdropdownby) {

		if (driver != null) {
			if (selectdropdownby.equalsIgnoreCase("index")) {
				int changetoelement = Integer.parseInt(elementvalue);
				select.selectByIndex(changetoelement);
			} else if (selectdropdownby.equalsIgnoreCase("value")) {
				select.selectByValue(elementvalue);
			} else {
				select.selectByVisibleText(elementvalue);
			}
		}
	}

	public void actionElement(String webelement, String locator) throws Exception {
		actions = new Actions(driver);
		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				actions.scrollToElement(driver.findElement(By.xpath(webelement))).perform();
			} else if (locator.equalsIgnoreCase("id")) {
				actions.scrollToElement(driver.findElement(By.id(webelement))).perform();
			}
		}
	}
	/*public void validationOnWebelementText(String webelement,String locator,String actualText) {
		
		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				Assert.assertEquals(actualText,driver.findElement(By.xpath(webelement)).getText());
			} else if (locator.equalsIgnoreCase("id")) {
				Assert.assertEquals(actualText,driver.findElement(By.xpath(webelement)).getText());
			}
		}
*/
		
	}

