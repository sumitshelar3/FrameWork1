package com.nopcommerce.pages;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import com.nopcommerce.core.SeleniumCoreMethods;

public class DesktopsPage extends SeleniumCoreMethods {

	String sortBy = "//select[@id='products-orderby']";
	String firstClickOnAddToCart = "(//button[contains(text(),'Add to cart')])[1]";
	HashMap<String, String> readdata;
	
	public DesktopsPage(WebDriver driver,HashMap<String, String> readdata) {
		
		super(driver);
		this.readdata = readdata;
	}

	public void sortBy() {
//		WebElement sortDropDown = driver.findElement(By.xpath(sortBy));
//		Select s = new Select(sortDropDown);
//		s.selectByVisibleText("Price: High to Low");
		dropDownElement(sortBy, "xpath",readdata.get("SortBy"), "");
	}

	public void clickOnAddToCart() throws Exception {
//		actions = new Actions(driver);
//		actions.scrollToElement(driver.findElement(By.xpath(firstClickOnAddToCart))).perform();
//		Thread.sleep(5000);
//		driver.findElement(By.xpath(firstClickOnAddToCart)).click();
        actionElement(firstClickOnAddToCart,"xpath");
		clickElementBy(firstClickOnAddToCart, "xpath");
	}
	
	public void fullFlowComputerTest() throws Exception
	{
		sortBy();
		clickOnAddToCart();
	}
	public void clickFullFlowComputerTest1() throws Exception
	{
		sortBy();	
	}
	public void clickFullFlowComputerTest2() throws Exception
	{
		clickOnAddToCart();
	}
}
