package com.nopcommerce.pages;

import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import com.nopcommerce.commonverifytext.NopCommerceVerifyText;
import com.nopcommerce.core.SeleniumCoreMethods;

public class LoginPage extends SeleniumCoreMethods  { //implements NopCommerceVerifyText

	String emailField = "Email";
	String passwordField = "Password";
	String loginButton = "//button[@class='button-1 login-button']";
	
	//String verifyFnameField="//div[@id='first_name_error'])";

	HashMap<String, String> readdata;

	public LoginPage(WebDriver driver, HashMap<String, String> readdata) {

		super(driver);
		this.readdata = readdata;
	}

	public void enterEmail() {

		// driver.findElement(By.id(emailField)).sendKeys("sumitshelar33@gmail.com");
		sendKeysElement(emailField, "id", readdata.get("Email_ID"));
	}

	public void enterPassword() {

		// driver.findElement(By.id(passwordField)).sendKeys("Temp@123");
		sendKeysElement(passwordField, "id", readdata.get("Password"));
	}

	public void clickOnLogin() {

		// driver.findElement(By.xpath(loginButton)).click();
		clickElementBy(loginButton, "xpath");
	}

	public void setUpLogin() {
//		if(i == 1)
		sendKeysElement(emailField, "id", readdata.get("Email_ID"));
		sendKeysElement(passwordField, "id", readdata.get("Password"));
		clickElementBy(loginButton, "xpath");

//		else if 2 
//		enterEmail();
//		clickOnLogin();	
	}
	
//	public void verifyValidationMsg() {
//		
//		validationOnWebelementText(verifyFnameField,"id", verifyTextFnameActualText);
	    
//	}
}
