package com.nopcommerce.pages;

import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import com.nopcommerce.core.SeleniumCoreMethods;

public class ShoppingCartPage extends SeleniumCoreMethods {

	String giftWrappingDropDown = "checkout_attribute_1";
	String checkoutButton = "//button[@id='checkout']";
	String termsCheckBox = "termsofservice";
	HashMap<String, String> readdata;
	public ShoppingCartPage(WebDriver driver,HashMap<String, String> readdata) {
		// TODO Auto-generated constructor stub
		super(driver);
		this.readdata = readdata;
	}

	public void giftWrapping(String wrappingvalue) {
//		WebElement dropDownGiftWrapping = driver.findElement(By.id("checkout_attribute_1"));
//		Select s1=new Select(dropDownGiftWrapping);
//		s1.selectByVisibleText("Yes [+$10.00]");
		dropDownElement(giftWrappingDropDown, "id",wrappingvalue, "");
	}

	public void termsAgreement() {
		// driver.findElement(By.id("termsofservice")).click();
		clickElementBy(termsCheckBox, "id");
	}

	public void clickOnCheckout() {
		// driver.findElement(By.xpath(checkoutButton)).click();
		clickElementBy(checkoutButton, "xpath");
	}

	public void giftWrappingCheckout() {
		giftWrapping(readdata.get("WrappingValue"));
		termsAgreement();
		clickOnCheckout();
	}
}
