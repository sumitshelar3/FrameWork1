package com.nopcommerce.pages;

import org.openqa.selenium.WebDriver;
import com.nopcommerce.core.SeleniumCoreMethods;

public class ComputerPage extends SeleniumCoreMethods {
	String desktopOption = "//img[@title='Show products in category Desktops']";
	String notebooksOption = "//img[@title='Show products in category Notebooks']";
	String softwareOption = "//img[@title='Show products in category Software']";

	public ComputerPage(WebDriver driver) {
		super(driver);
	}

	public void clickOnDesktops() {
		// driver.findElement(By.xpath(desktopOption)).click();
		clickElementBy(desktopOption, "xpath");

	}

	public void clickOnNotebooks() {
		// driver.findElement(By.xpath(notebooksOption)).click();
		clickElementBy(notebooksOption, "xpath");
	}

	public void clickOnSoftware() {
		// driver.findElement(By.xpath(softwareOption)).click();
		clickElementBy(softwareOption, "xpath");
	}
}
