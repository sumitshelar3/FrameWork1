package com.nopcommerce.pages;

import org.openqa.selenium.WebDriver;
import com.nopcommerce.commonfields.NopCommerceFields;
import com.nopcommerce.core.SeleniumCoreMethods;

public class HomePage extends SeleniumCoreMethods implements NopCommerceFields {

	public HomePage(WebDriver driver) {
		//SeleniumCoreMethods seleniumcore = new SeleniumCoreMethods(driver);
		super(driver);
	}

	public void clickOnLogIn() {
		// driver.findElement(By.xpath(loginClick)).click();
		clickElementBy(loginClick, "xpath");
	}

	public void clickOnComputers() {
		// driver.findElement(By.xpath(computerClick)).click();
		clickElementBy(computerClick, "xpath");
	}

	public void clickOnElements() {
		// driver.findElement(By.xpath(elementsClick)).click();
		clickElementBy(elementsClick, "xpath");
	}

	public void clickOnApparel() {
		// driver.findElement(By.xpath(apparelClick)).click();
		clickElementBy(apparelClick, "xpath");
	}

	public void clickOnShoppingCart() {
		// driver.findElement(By.xpath(shoppingCartClick)).click();
		clickElementBy(shoppingCartClick, "xpath");
	}

}
