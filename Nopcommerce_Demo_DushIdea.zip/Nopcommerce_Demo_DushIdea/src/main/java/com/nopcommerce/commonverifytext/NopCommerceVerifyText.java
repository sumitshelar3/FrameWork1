package com.nopcommerce.commonverifytext;

public interface NopCommerceVerifyText {
	String verifyTextFnameActualText = "First Name is required.";
	
}
