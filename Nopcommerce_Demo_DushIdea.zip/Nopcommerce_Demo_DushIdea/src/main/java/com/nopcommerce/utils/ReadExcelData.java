package com.nopcommerce.utils;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.io.File;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {

	public static HashMap<String, String> readdata = new HashMap<String, String>();

	public static HashMap<String, String> readDataTest(String testcasename) throws Exception {
		try {
			FileInputStream file = new FileInputStream(
					new File(System.getProperty("user.dir") + "//Data" + File.separator + "TestData.xlsx"));
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet mySheet = workbook.getSheet("Sheet1");

			int cellCount = 0;
			Iterator rowIterator = mySheet.rowIterator();
			int rowCount = mySheet.getPhysicalNumberOfRows();
			if (rowIterator.hasNext()) {
				Row headerRow = (Row) rowIterator.next();
				cellCount = headerRow.getPhysicalNumberOfCells();

				for (int i = 1; i < rowCount; i++) {
					if (mySheet.getRow(i).getCell(0).getStringCellValue().equals(testcasename)) {
						for (int k = 0; k < cellCount; k++) {
							readdata.put(mySheet.getRow(0).getCell(k).getStringCellValue(),
									mySheet.getRow(i).getCell(k).getStringCellValue());
						}
						// test.log(LogStatus.PASS, "Able to read data from excel file");
						// CustomTestLogger.writePass("Able to read data from excel file", true);
						// System.out.println(properties);
						// return read_hashmap;
					}
				}
			}
		}

		catch (Exception e) {
			// test.log(LogStatus.FAIL, "Read Excel error " + e);
			// CustomTestLogger.writeFailure("Read Excel error " + e, true);
		}
	
		return readdata;
	}
}
